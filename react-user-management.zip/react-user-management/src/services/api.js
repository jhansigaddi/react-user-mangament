// Lightweight API wrapper using JSONPlaceholder for simulated CRUD.
const BASE = 'https://jsonplaceholder.typicode.com/users';

export async function fetchUsers(){
  const res = await fetch(BASE);
  if(!res.ok) throw new Error('Failed to fetch users');
  return res.json();
}

export async function createUserLocal(payload){
  const res = await fetch(BASE, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  if(!res.ok) throw new Error('Create failed');
  return res.json();
}

export async function getUserLocal(id){
  const res = await fetch(BASE + '/' + id);
  if(!res.ok) throw new Error('User not found');
  return res.json();
}

export async function updateUserLocal(id, payload){
  const res = await fetch(BASE + '/' + id, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  if(!res.ok) throw new Error('Update failed');
  return res.json();
}

export async function deleteUserLocal(id){
  const res = await fetch(BASE + '/' + id, { method:'DELETE' });
  if(!res.ok) throw new Error('Delete failed');
  return { success:true };
}
