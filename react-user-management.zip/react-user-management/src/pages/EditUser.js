import React, { useEffect, useState } from 'react';
import UserForm from '../components/UserForm';
import { getUserLocal, updateUserLocal } from '../services/api';
import { useNavigate, useParams } from 'react-router-dom';

export default function EditUser(){
  const { id } = useParams();
  const nav = useNavigate();
  const [initial, setInitial] = useState(null);

  useEffect(()=>{
    getUserLocal(id).then(u=> setInitial(u)).catch(()=> alert('User not found'));
  },[id]);

  const handleSubmit = async (data) => {
    try {
      await updateUserLocal(id, data);
      alert('User updated (simulated).');
      nav('/');
    } catch(e){
      alert('Update failed: '+(e.message||e));
    }
  };

  if(!initial) return <div className='app-container'><div className='card'>Loading user…</div></div>;
  return (
    <div className='app-container'>
      <h2>Edit User</h2>
      <UserForm initial={initial} onSubmit={handleSubmit} />
    </div>
  );
}
