import React, { useEffect, useState } from 'react';
import UserList from '../components/UserList';
import { fetchUsers, deleteUserLocal } from '../services/api';

export default function Home(){
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(()=>{
    setLoading(true);
    fetchUsers()
      .then(data => setUsers(data))
      .catch(e => setError(e.message||'Fetch error'))
      .finally(()=> setLoading(false));
  },[]);

  async function handleDelete(id){
    // JSONPlaceholder won't remove permanently; we simulate
    try {
      await deleteUserLocal(id);
      setUsers(users.filter(u=>u.id!==id));
    } catch(e) {
      alert('Delete failed: '+(e.message||e));
    }
  }

  return (
    <div className="app-container">
      <h2>Users</h2>
      {loading && <div className="card">Loading users…</div>}
      {error && <div className="card" style={{color:'red'}}>{error}</div>}
      {!loading && !error && <UserList users={users} onDelete={handleDelete} />}
    </div>
  );
}
