import React from 'react';
import UserForm from '../components/UserForm';
import { createUserLocal } from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function AddUser(){
  const nav = useNavigate();
  const handleSubmit = async (data) => {
    try {
      await createUserLocal(data);
      alert('User created (simulated).');
      nav('/');
    } catch(e){
      alert('Create failed: '+(e.message||e));
    }
  };
  return (
    <div className="app-container">
      <h2>Add User</h2>
      <UserForm onSubmit={handleSubmit} />
    </div>
  );
}
