import React, { useState, useEffect } from 'react';

export default function UserForm({ initial = {name:'', email:'', phone:''}, onSubmit }){
  const [form, setForm] = useState(initial);
  useEffect(()=> setForm(initial), [initial]);
  const handle = (e) => setForm({...form, [e.target.name]: e.target.value});
  return (
    <form className='card' onSubmit={(e)=>{ e.preventDefault(); onSubmit(form); }}>
      <div style={{display:'flex', gap:8, alignItems:'center'}}>
        <input name='name' placeholder='Full name' value={form.name} onChange={handle} required />
        <input name='email' placeholder='Email' value={form.email} onChange={handle} required />
        <input name='phone' placeholder='Phone' value={form.phone} onChange={handle} />
        <button type='submit' className='btn'>{initial && initial.id ? 'Update' : 'Create'}</button>
      </div>
    </form>
  );
}
