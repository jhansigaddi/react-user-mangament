import React from 'react';
import { Link } from 'react-router-dom';

export default function UserList({ users, onDelete }){
  return (
    <div className="user-list card">
      {users.length === 0 ? <p>No users yet.</p> : users.map(u => (
        <div key={u.id} className="user-item">
          <div>
            <div style={{fontWeight:600}}>{u.name}</div>
            <div style={{fontSize:13, color:'#374151'}}>{u.email} • {u.phone || '-'}</div>
          </div>
          <div>
            <Link to={`/edit/${u.id}`} className="btn ghost" style={{marginRight:8}}>Edit</Link>
            <button className="btn" onClick={()=>onDelete(u.id)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}
